﻿namespace InventoryControlTRDWeb.Application.Enums
{
    public enum ProductType
    {
        UN = 1,
        PCT = 2,
        Weight = 3
    }
}
