﻿namespace InventoryControlTRDWeb.Application.Enums
{
    public enum MovimentType
    {
        Out = 1,
        In = 2
    }
}
