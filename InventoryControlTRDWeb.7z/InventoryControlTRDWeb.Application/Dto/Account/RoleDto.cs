﻿namespace InventoryControlTRDWeb.Application.Dto
{
    public class RoleDto : BaseDto
    {
        public string Name { get; set; }
    }
}
