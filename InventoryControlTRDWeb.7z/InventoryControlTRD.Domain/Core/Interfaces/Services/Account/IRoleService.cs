﻿using InventoryControlTRD.Domain.Models;

namespace InventoryControlTRD.Domain.Core.Interfaces.Services
{
    public interface IRoleService : IBaseService<Role>
    {
    }
}
