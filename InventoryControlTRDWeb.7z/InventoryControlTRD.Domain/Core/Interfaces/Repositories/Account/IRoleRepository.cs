﻿using InventoryControlTRD.Domain.Models;

namespace InventoryControlTRD.Domain.Core.Interfaces.Repositories
{
    public interface IRoleRepository : IBaseRepository<Role>
    {
    }
}
